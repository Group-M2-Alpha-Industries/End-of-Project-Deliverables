-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 18, 2023 at 04:03 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jot bikes_mysql`
--

-- --------------------------------------------------------

--
-- Table structure for table `accessories`
--

CREATE TABLE `accessories` (
  `Accessories_id` int(11) NOT NULL,
  `Accessories_Name` varchar(50) NOT NULL,
  `product_type` varchar(50) NOT NULL,
  `Description` int(11) NOT NULL,
  `Quantity` int(11) NOT NULL,
  `photo_id` int(11) NOT NULL,
  `Accessories_price` int(11) NOT NULL,
  `Category_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `Admin_Name` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `Appointment_number` int(11) NOT NULL,
  `User_id` varchar(50) NOT NULL,
  `Ticket_number` int(11) NOT NULL,
  `Description` text NOT NULL,
  `To Address` varchar(50) NOT NULL,
  `To city` varchar(10) NOT NULL,
  `To state` varchar(10) NOT NULL,
  `Time` time NOT NULL,
  `Booking date/time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bikes`
--

CREATE TABLE `bikes` (
  `Bike_id` int(11) NOT NULL,
  `Bike_name` varchar(50) NOT NULL,
  `product_type` varchar(50) NOT NULL,
  `Description` int(11) NOT NULL,
  `Quantity` int(11) NOT NULL,
  `photo_id` int(11) NOT NULL,
  `Bike_price` int(11) NOT NULL,
  `Category_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `booking/rental`
--

CREATE TABLE `booking/rental` (
  `Booking_number` int(11) NOT NULL,
  `Ticket_number` int(11) NOT NULL,
  `Bike_id` int(11) NOT NULL,
  `User_id` varchar(50) NOT NULL,
  `Rental cost` int(11) NOT NULL,
  `To address` varchar(10) NOT NULL,
  `To city` varchar(10) NOT NULL,
  `To state` varchar(10) NOT NULL,
  `Rental duration` int(11) NOT NULL,
  `Time` time NOT NULL,
  `Booking Status` varchar(50) NOT NULL,
  `Booking date/time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(50) NOT NULL,
  `Description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `discount code`
--

CREATE TABLE `discount code` (
  `Discount_code` varchar(50) NOT NULL,
  `Admin_Name` varchar(50) NOT NULL,
  `Quantity` int(11) NOT NULL,
  `Discount_Type` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `feedbacks`
--

CREATE TABLE `feedbacks` (
  `Feedback_id` int(11) NOT NULL,
  `Admin_Name` varchar(50) NOT NULL,
  `Vendor_id` int(11) NOT NULL,
  `User_id` varchar(50) NOT NULL,
  `Description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `invoice`
--

CREATE TABLE `invoice` (
  `Invoice_id` int(11) NOT NULL,
  `payment_id` int(11) NOT NULL,
  `Order_number` int(11) NOT NULL,
  `Appointment_number` int(11) NOT NULL,
  `Booking_number` int(11) NOT NULL,
  `Datetime` datetime NOT NULL,
  `Description` text NOT NULL,
  `User_id` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `manage accessories`
--

CREATE TABLE `manage accessories` (
  `Manage Accessories_id` int(11) NOT NULL,
  `Accessories_id` int(11) NOT NULL,
  `Admin_name` varchar(50) NOT NULL,
  `Vendor_id` int(11) NOT NULL,
  `Date` date NOT NULL,
  `Quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `manage bikes`
--

CREATE TABLE `manage bikes` (
  `Manage Bikes_id` int(11) NOT NULL,
  `Bike_id` int(11) NOT NULL,
  `Admin_name` varchar(50) NOT NULL,
  `Vendor_id` int(11) NOT NULL,
  `Category_id` int(11) NOT NULL,
  `Quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `manage orders`
--

CREATE TABLE `manage orders` (
  `Manage Order_id` int(11) NOT NULL,
  `order_number` int(11) NOT NULL,
  `Admin_name` varchar(50) NOT NULL,
  `Vendor_id` int(11) NOT NULL,
  `Description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `manage refund`
--

CREATE TABLE `manage refund` (
  `Refund_id` int(11) NOT NULL,
  `Report_id` int(11) NOT NULL,
  `Admin_name` varchar(50) NOT NULL,
  `Vendor_id` int(11) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `Refund status` varchar(50) NOT NULL,
  `Date/Time` datetime NOT NULL,
  `Quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `manage returns`
--

CREATE TABLE `manage returns` (
  `Returns_id` int(11) NOT NULL,
  `Report_id` int(11) NOT NULL,
  `Admin_name` varchar(50) NOT NULL,
  `Vendor_id` int(11) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `Return status` varchar(10) NOT NULL,
  `Date/Time` datetime NOT NULL,
  `Quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `manage vendor`
--

CREATE TABLE `manage vendor` (
  `Manage vendor_id` int(11) NOT NULL,
  `Admin_Name` varchar(50) NOT NULL,
  `Vendor_id` int(11) NOT NULL,
  `Add/Delete` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `Order_number` int(11) NOT NULL,
  `User_id` varchar(50) NOT NULL,
  `Customer_name` varchar(50) NOT NULL,
  `To address` varchar(50) NOT NULL,
  `To city` varchar(10) NOT NULL,
  `To state` varchar(10) NOT NULL,
  `Ship date/time` datetime NOT NULL,
  `Bike_id` int(11) NOT NULL,
  `Parts_id` int(11) NOT NULL,
  `Accessories_id` int(11) NOT NULL,
  `wishlist_id` int(11) NOT NULL,
  `Discount_code` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `parts`
--

CREATE TABLE `parts` (
  `Parts_id` int(11) NOT NULL,
  `Parts_name` varchar(50) NOT NULL,
  `product_type` varchar(50) NOT NULL,
  `Description` int(11) NOT NULL,
  `Quantity` int(11) NOT NULL,
  `photo_id` int(11) NOT NULL,
  `Parts_price` int(11) NOT NULL,
  `Category_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `payment_id` int(11) NOT NULL,
  `order_number` int(11) NOT NULL,
  `Booking_number` int(11) NOT NULL,
  `Appointment_number` int(11) NOT NULL,
  `Parts_id` int(11) NOT NULL,
  `update_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `photos`
--

CREATE TABLE `photos` (
  `Photo_id` int(11) NOT NULL,
  `Photo` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `rental history`
--

CREATE TABLE `rental history` (
  `Rental_id` int(11) NOT NULL,
  `User_id` varchar(50) NOT NULL,
  `Report_id` int(11) NOT NULL,
  `Booking_number` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sales report`
--

CREATE TABLE `sales report` (
  `Report_id` int(11) NOT NULL,
  `Invoice_id` int(11) NOT NULL,
  `Admin_name` varchar(50) NOT NULL,
  `Vendor_id` int(11) NOT NULL,
  `Order_number` int(11) NOT NULL,
  `booking_number` int(11) NOT NULL,
  `Total Revenue` int(11) NOT NULL,
  `Date/time` datetime NOT NULL,
  `Description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `shipment`
--

CREATE TABLE `shipment` (
  `Shipping_id` int(11) NOT NULL,
  `Bike_id` int(11) NOT NULL,
  `Accessories_id` int(11) NOT NULL,
  `Order_number` int(11) NOT NULL,
  `payment_id` int(11) NOT NULL,
  `ChargecardTime` datetime NOT NULL,
  `Packing time` time NOT NULL,
  `Ship Order Date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ticket`
--

CREATE TABLE `ticket` (
  `Ticket Number` int(11) NOT NULL,
  `User_id` varchar(50) NOT NULL,
  `Data time` datetime NOT NULL,
  `Description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `User_id` varchar(50) NOT NULL,
  `First Name` varchar(50) NOT NULL,
  `Middle Name` varchar(50) NOT NULL,
  `Last Name` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Country` varchar(40) NOT NULL,
  `Address` varchar(40) NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(30) NOT NULL,
  `postcode` int(5) NOT NULL,
  `phone` int(10) NOT NULL,
  `Date of birth` date NOT NULL,
  `Gender` char(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `vendor`
--

CREATE TABLE `vendor` (
  `Vendor_id` int(11) NOT NULL,
  `First Name` varchar(50) NOT NULL,
  `Middle Name` varchar(50) NOT NULL,
  `Last Name` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Phone` varchar(10) NOT NULL,
  `Date of birth` datetime NOT NULL,
  `Gender` char(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

CREATE TABLE `wishlist` (
  `Wishlist_id` int(11) NOT NULL,
  `User_id` varchar(50) NOT NULL,
  `Bike_id` int(11) NOT NULL,
  `Accessories_id` int(11) NOT NULL,
  `Parts_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accessories`
--
ALTER TABLE `accessories`
  ADD PRIMARY KEY (`Accessories_id`),
  ADD KEY `photo_id` (`photo_id`),
  ADD KEY `Category_id` (`Category_id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`Admin_Name`);

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`Appointment_number`),
  ADD KEY `User_id` (`User_id`),
  ADD KEY `Ticket_number` (`Ticket_number`);

--
-- Indexes for table `bikes`
--
ALTER TABLE `bikes`
  ADD PRIMARY KEY (`Bike_id`),
  ADD KEY `photo_id` (`photo_id`),
  ADD KEY `Category_id` (`Category_id`);

--
-- Indexes for table `booking/rental`
--
ALTER TABLE `booking/rental`
  ADD PRIMARY KEY (`Booking_number`),
  ADD KEY `Bike_id` (`Bike_id`),
  ADD KEY `User_id` (`User_id`),
  ADD KEY `Ticket_number` (`Ticket_number`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `discount code`
--
ALTER TABLE `discount code`
  ADD PRIMARY KEY (`Discount_code`),
  ADD KEY `Admin_Name` (`Admin_Name`);

--
-- Indexes for table `feedbacks`
--
ALTER TABLE `feedbacks`
  ADD PRIMARY KEY (`Feedback_id`),
  ADD KEY `Admin_Name` (`Admin_Name`),
  ADD KEY `Vendor_id` (`Vendor_id`),
  ADD KEY `User_id` (`User_id`);

--
-- Indexes for table `invoice`
--
ALTER TABLE `invoice`
  ADD PRIMARY KEY (`Invoice_id`),
  ADD KEY `payment_id` (`payment_id`),
  ADD KEY `Appointment_number` (`Appointment_number`),
  ADD KEY `Order_number` (`Order_number`),
  ADD KEY `Booking_number` (`Booking_number`),
  ADD KEY `User_id` (`User_id`);

--
-- Indexes for table `manage accessories`
--
ALTER TABLE `manage accessories`
  ADD PRIMARY KEY (`Manage Accessories_id`),
  ADD KEY `Accessories_id` (`Accessories_id`),
  ADD KEY `Admin_name` (`Admin_name`),
  ADD KEY `Vendor_id` (`Vendor_id`);

--
-- Indexes for table `manage bikes`
--
ALTER TABLE `manage bikes`
  ADD PRIMARY KEY (`Manage Bikes_id`),
  ADD KEY `Bike_id` (`Bike_id`),
  ADD KEY `Admin_name` (`Admin_name`),
  ADD KEY `Vendor_id` (`Vendor_id`);

--
-- Indexes for table `manage orders`
--
ALTER TABLE `manage orders`
  ADD PRIMARY KEY (`Manage Order_id`),
  ADD KEY `order_number` (`order_number`),
  ADD KEY `Admin_name` (`Admin_name`),
  ADD KEY `Vendor_id` (`Vendor_id`);

--
-- Indexes for table `manage refund`
--
ALTER TABLE `manage refund`
  ADD PRIMARY KEY (`Refund_id`),
  ADD KEY `Admin_name` (`Admin_name`),
  ADD KEY `Report_id` (`Report_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `Vendor_id` (`Vendor_id`);

--
-- Indexes for table `manage returns`
--
ALTER TABLE `manage returns`
  ADD PRIMARY KEY (`Returns_id`),
  ADD KEY `Report_id` (`Report_id`),
  ADD KEY `Admin_name` (`Admin_name`),
  ADD KEY `Vendor_id` (`Vendor_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `manage vendor`
--
ALTER TABLE `manage vendor`
  ADD PRIMARY KEY (`Manage vendor_id`),
  ADD KEY `Admin_Name` (`Admin_Name`),
  ADD KEY `Vendor_id` (`Vendor_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`Order_number`),
  ADD KEY `User_id` (`User_id`),
  ADD KEY `Bike_id` (`Bike_id`),
  ADD KEY `Parts_id` (`Parts_id`),
  ADD KEY `Accessories_id` (`Accessories_id`),
  ADD KEY `wishlist_id` (`wishlist_id`),
  ADD KEY `Discount_code` (`Discount_code`);

--
-- Indexes for table `parts`
--
ALTER TABLE `parts`
  ADD PRIMARY KEY (`Parts_id`),
  ADD KEY `photo_id` (`photo_id`),
  ADD KEY `Category_id` (`Category_id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`payment_id`),
  ADD KEY `order_number` (`order_number`),
  ADD KEY `Booking_number` (`Booking_number`),
  ADD KEY `Appointment_number` (`Appointment_number`);

--
-- Indexes for table `photos`
--
ALTER TABLE `photos`
  ADD PRIMARY KEY (`Photo_id`);

--
-- Indexes for table `rental history`
--
ALTER TABLE `rental history`
  ADD PRIMARY KEY (`Rental_id`),
  ADD KEY `User_id` (`User_id`),
  ADD KEY `Report_id` (`Report_id`),
  ADD KEY `Booking_number` (`Booking_number`);

--
-- Indexes for table `sales report`
--
ALTER TABLE `sales report`
  ADD PRIMARY KEY (`Report_id`),
  ADD KEY `Invoice_id` (`Invoice_id`),
  ADD KEY `Admin_name` (`Admin_name`),
  ADD KEY `Vendor_id` (`Vendor_id`),
  ADD KEY `Order_number` (`Order_number`),
  ADD KEY `booking_number` (`booking_number`);

--
-- Indexes for table `shipment`
--
ALTER TABLE `shipment`
  ADD KEY `Bike_id` (`Bike_id`),
  ADD KEY `Accessories_id` (`Accessories_id`),
  ADD KEY `Order_number` (`Order_number`),
  ADD KEY `payment_id` (`payment_id`);

--
-- Indexes for table `ticket`
--
ALTER TABLE `ticket`
  ADD PRIMARY KEY (`Ticket Number`),
  ADD KEY `User_id` (`User_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`User_id`);

--
-- Indexes for table `vendor`
--
ALTER TABLE `vendor`
  ADD PRIMARY KEY (`Vendor_id`);

--
-- Indexes for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD PRIMARY KEY (`Wishlist_id`),
  ADD KEY `User_id` (`User_id`),
  ADD KEY `Bike_id` (`Bike_id`),
  ADD KEY `Accessories_id` (`Accessories_id`),
  ADD KEY `Parts_id` (`Parts_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `accessories`
--
ALTER TABLE `accessories`
  ADD CONSTRAINT `accessories_ibfk_1` FOREIGN KEY (`photo_id`) REFERENCES `photos` (`Photo_id`),
  ADD CONSTRAINT `accessories_ibfk_2` FOREIGN KEY (`Category_id`) REFERENCES `categories` (`category_id`);

--
-- Constraints for table `appointment`
--
ALTER TABLE `appointment`
  ADD CONSTRAINT `appointment_ibfk_1` FOREIGN KEY (`User_id`) REFERENCES `user` (`User_id`),
  ADD CONSTRAINT `appointment_ibfk_2` FOREIGN KEY (`Ticket_number`) REFERENCES `ticket` (`Ticket Number`);

--
-- Constraints for table `bikes`
--
ALTER TABLE `bikes`
  ADD CONSTRAINT `bikes_ibfk_1` FOREIGN KEY (`photo_id`) REFERENCES `photos` (`Photo_id`),
  ADD CONSTRAINT `bikes_ibfk_2` FOREIGN KEY (`Category_id`) REFERENCES `categories` (`category_id`);

--
-- Constraints for table `booking/rental`
--
ALTER TABLE `booking/rental`
  ADD CONSTRAINT `booking/rental_ibfk_1` FOREIGN KEY (`Bike_id`) REFERENCES `bikes` (`Bike_id`),
  ADD CONSTRAINT `booking/rental_ibfk_2` FOREIGN KEY (`User_id`) REFERENCES `user` (`User_id`),
  ADD CONSTRAINT `booking/rental_ibfk_3` FOREIGN KEY (`Ticket_number`) REFERENCES `ticket` (`Ticket Number`),
  ADD CONSTRAINT `booking/rental_ibfk_4` FOREIGN KEY (`Ticket_number`) REFERENCES `ticket` (`Ticket Number`);

--
-- Constraints for table `discount code`
--
ALTER TABLE `discount code`
  ADD CONSTRAINT `discount code_ibfk_1` FOREIGN KEY (`Admin_Name`) REFERENCES `admin` (`Admin_Name`);

--
-- Constraints for table `feedbacks`
--
ALTER TABLE `feedbacks`
  ADD CONSTRAINT `feedbacks_ibfk_1` FOREIGN KEY (`Admin_Name`) REFERENCES `admin` (`Admin_Name`),
  ADD CONSTRAINT `feedbacks_ibfk_2` FOREIGN KEY (`Vendor_id`) REFERENCES `vendor` (`Vendor_id`),
  ADD CONSTRAINT `feedbacks_ibfk_3` FOREIGN KEY (`User_id`) REFERENCES `user` (`User_id`);

--
-- Constraints for table `invoice`
--
ALTER TABLE `invoice`
  ADD CONSTRAINT `invoice_ibfk_1` FOREIGN KEY (`payment_id`) REFERENCES `payment` (`payment_id`),
  ADD CONSTRAINT `invoice_ibfk_2` FOREIGN KEY (`Appointment_number`) REFERENCES `appointment` (`Appointment_number`),
  ADD CONSTRAINT `invoice_ibfk_3` FOREIGN KEY (`Order_number`) REFERENCES `orders` (`Order_number`),
  ADD CONSTRAINT `invoice_ibfk_4` FOREIGN KEY (`Booking_number`) REFERENCES `booking/rental` (`Booking_number`),
  ADD CONSTRAINT `invoice_ibfk_5` FOREIGN KEY (`User_id`) REFERENCES `user` (`User_id`);

--
-- Constraints for table `manage accessories`
--
ALTER TABLE `manage accessories`
  ADD CONSTRAINT `manage accessories_ibfk_1` FOREIGN KEY (`Accessories_id`) REFERENCES `accessories` (`Accessories_id`),
  ADD CONSTRAINT `manage accessories_ibfk_2` FOREIGN KEY (`Admin_name`) REFERENCES `admin` (`Admin_Name`),
  ADD CONSTRAINT `manage accessories_ibfk_3` FOREIGN KEY (`Vendor_id`) REFERENCES `vendor` (`Vendor_id`);

--
-- Constraints for table `manage bikes`
--
ALTER TABLE `manage bikes`
  ADD CONSTRAINT `manage bikes_ibfk_1` FOREIGN KEY (`Bike_id`) REFERENCES `bikes` (`Bike_id`),
  ADD CONSTRAINT `manage bikes_ibfk_2` FOREIGN KEY (`Admin_name`) REFERENCES `admin` (`Admin_Name`),
  ADD CONSTRAINT `manage bikes_ibfk_3` FOREIGN KEY (`Vendor_id`) REFERENCES `vendor` (`Vendor_id`);

--
-- Constraints for table `manage orders`
--
ALTER TABLE `manage orders`
  ADD CONSTRAINT `manage orders_ibfk_1` FOREIGN KEY (`order_number`) REFERENCES `orders` (`Order_number`),
  ADD CONSTRAINT `manage orders_ibfk_2` FOREIGN KEY (`Admin_name`) REFERENCES `admin` (`Admin_Name`),
  ADD CONSTRAINT `manage orders_ibfk_3` FOREIGN KEY (`Vendor_id`) REFERENCES `vendor` (`Vendor_id`);

--
-- Constraints for table `manage refund`
--
ALTER TABLE `manage refund`
  ADD CONSTRAINT `manage refund_ibfk_1` FOREIGN KEY (`Admin_name`) REFERENCES `admin` (`Admin_Name`),
  ADD CONSTRAINT `manage refund_ibfk_2` FOREIGN KEY (`Report_id`) REFERENCES `sales report` (`Report_id`),
  ADD CONSTRAINT `manage refund_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `user` (`User_id`),
  ADD CONSTRAINT `manage refund_ibfk_4` FOREIGN KEY (`Vendor_id`) REFERENCES `vendor` (`Vendor_id`);

--
-- Constraints for table `manage returns`
--
ALTER TABLE `manage returns`
  ADD CONSTRAINT `manage returns_ibfk_1` FOREIGN KEY (`Report_id`) REFERENCES `sales report` (`Report_id`),
  ADD CONSTRAINT `manage returns_ibfk_2` FOREIGN KEY (`Admin_name`) REFERENCES `admin` (`Admin_Name`),
  ADD CONSTRAINT `manage returns_ibfk_3` FOREIGN KEY (`Vendor_id`) REFERENCES `vendor` (`Vendor_id`),
  ADD CONSTRAINT `manage returns_ibfk_4` FOREIGN KEY (`user_id`) REFERENCES `user` (`User_id`);

--
-- Constraints for table `manage vendor`
--
ALTER TABLE `manage vendor`
  ADD CONSTRAINT `manage vendor_ibfk_1` FOREIGN KEY (`Admin_Name`) REFERENCES `admin` (`Admin_Name`),
  ADD CONSTRAINT `manage vendor_ibfk_2` FOREIGN KEY (`Vendor_id`) REFERENCES `vendor` (`Vendor_id`);

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`User_id`) REFERENCES `user` (`User_id`),
  ADD CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`Bike_id`) REFERENCES `bikes` (`Bike_id`),
  ADD CONSTRAINT `orders_ibfk_3` FOREIGN KEY (`Parts_id`) REFERENCES `parts` (`Parts_id`),
  ADD CONSTRAINT `orders_ibfk_4` FOREIGN KEY (`Accessories_id`) REFERENCES `accessories` (`Accessories_id`),
  ADD CONSTRAINT `orders_ibfk_5` FOREIGN KEY (`wishlist_id`) REFERENCES `wishlist` (`Wishlist_id`),
  ADD CONSTRAINT `orders_ibfk_6` FOREIGN KEY (`Discount_code`) REFERENCES `discount code` (`Discount_code`);

--
-- Constraints for table `parts`
--
ALTER TABLE `parts`
  ADD CONSTRAINT `parts_ibfk_1` FOREIGN KEY (`photo_id`) REFERENCES `photos` (`Photo_id`),
  ADD CONSTRAINT `parts_ibfk_2` FOREIGN KEY (`Category_id`) REFERENCES `categories` (`category_id`);

--
-- Constraints for table `payment`
--
ALTER TABLE `payment`
  ADD CONSTRAINT `payment_ibfk_1` FOREIGN KEY (`order_number`) REFERENCES `orders` (`Order_number`),
  ADD CONSTRAINT `payment_ibfk_2` FOREIGN KEY (`Booking_number`) REFERENCES `booking/rental` (`Booking_number`),
  ADD CONSTRAINT `payment_ibfk_3` FOREIGN KEY (`Appointment_number`) REFERENCES `appointment` (`Appointment_number`);

--
-- Constraints for table `rental history`
--
ALTER TABLE `rental history`
  ADD CONSTRAINT `rental history_ibfk_1` FOREIGN KEY (`User_id`) REFERENCES `user` (`User_id`),
  ADD CONSTRAINT `rental history_ibfk_2` FOREIGN KEY (`Report_id`) REFERENCES `sales report` (`Report_id`),
  ADD CONSTRAINT `rental history_ibfk_3` FOREIGN KEY (`Booking_number`) REFERENCES `booking/rental` (`Booking_number`);

--
-- Constraints for table `sales report`
--
ALTER TABLE `sales report`
  ADD CONSTRAINT `sales report_ibfk_1` FOREIGN KEY (`Invoice_id`) REFERENCES `invoice` (`Invoice_id`),
  ADD CONSTRAINT `sales report_ibfk_2` FOREIGN KEY (`Admin_name`) REFERENCES `admin` (`Admin_Name`),
  ADD CONSTRAINT `sales report_ibfk_3` FOREIGN KEY (`Vendor_id`) REFERENCES `vendor` (`Vendor_id`),
  ADD CONSTRAINT `sales report_ibfk_4` FOREIGN KEY (`Order_number`) REFERENCES `orders` (`Order_number`),
  ADD CONSTRAINT `sales report_ibfk_5` FOREIGN KEY (`booking_number`) REFERENCES `booking/rental` (`Booking_number`);

--
-- Constraints for table `shipment`
--
ALTER TABLE `shipment`
  ADD CONSTRAINT `shipment_ibfk_1` FOREIGN KEY (`Bike_id`) REFERENCES `bikes` (`Bike_id`),
  ADD CONSTRAINT `shipment_ibfk_2` FOREIGN KEY (`Accessories_id`) REFERENCES `accessories` (`Accessories_id`),
  ADD CONSTRAINT `shipment_ibfk_3` FOREIGN KEY (`Order_number`) REFERENCES `orders` (`Order_number`),
  ADD CONSTRAINT `shipment_ibfk_4` FOREIGN KEY (`payment_id`) REFERENCES `payment` (`payment_id`);

--
-- Constraints for table `ticket`
--
ALTER TABLE `ticket`
  ADD CONSTRAINT `ticket_ibfk_1` FOREIGN KEY (`User_id`) REFERENCES `user` (`User_id`);

--
-- Constraints for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD CONSTRAINT `wishlist_ibfk_1` FOREIGN KEY (`User_id`) REFERENCES `user` (`User_id`),
  ADD CONSTRAINT `wishlist_ibfk_2` FOREIGN KEY (`Bike_id`) REFERENCES `bikes` (`Bike_id`),
  ADD CONSTRAINT `wishlist_ibfk_3` FOREIGN KEY (`Accessories_id`) REFERENCES `accessories` (`Accessories_id`),
  ADD CONSTRAINT `wishlist_ibfk_4` FOREIGN KEY (`Parts_id`) REFERENCES `parts` (`Parts_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
